from django.urls import path
from . import views


urlpatterns = [
    path('',views.home, name='home'),
    path('Get/',views.Yearlevel),
    path('Get/<int:pk>/',views.Yearlevel),
    path('Get/delete/<int:pk>',views.Yearlevel),


]   